Degel is a software development boutique, specializing in mobile applications for Symbian 
Series 60 and UIQ, J2ME, Pocket PC, Blackberry, BREW, and other platforms. We have been 
developing mobile applications continuously since early 2001, are Symbian Platinum Partners, 
and our applications have won Handango�s Champion awards.

We offer a full range of development services, from basic coaching to help your technical 
staff get started in a new environment to full scale turnkey development.  We have helped 
companies revitalize failing projects in as little as half a day of code review and have 
also spearheaded large development projects such as AOL�s instant messaging clients or 
Orange�s Series 60 PTT client. Our team consists of only senior developers, and includes 
former CTOs and senior managers.

For your convenience, we have put together a demo package of the trial versions for a 
number of the products that we have worked on for Symbian OS phones.  Please note that this 
is a representative list we are not at liberty to distribute examples of several of our 
more interesting projects, but the examples here should suffice to give you an idea of the 
range and quality of the services that we provide:

� NaturalRecorder � An automatic software-based mobile phone call recording tool with a 
  patent pending process for limiting the memory used by the recorded conversations.  
  NaturalRecorder runs on Series 60 phones and was developed in full by Degel Software 
  on behalf of NaturalWidgets.  

� Agendus � The Personal information Manager that tightly integrates three of the most-used 
  applications on your phone: contacts, calendar, and tasks. Degel Software developed the 
  UIQ version of Agendus on behalf of Iambic.

� BugMe! � A fun and easy-to-use Notes and Reminder application with camera and audio 
  integration.  Degel Software developed the Series 60 and UIQ versions of BugMe! (both 
  SIS files included) on behalf of Electric Pocket.

� WorldMate Professional � The best selling mobile application for travel is ideal for 
  helping the frequent business traveler to plan, manage and track business travel.  
  Degel Software assisted in the development of the UIQ version on behalf of MobiMate. 

� QuickOffice Premier � Enables you to open, edit, and save Microsoft Office compatible
  files on a mobile device. Degel Software supported MDM�s (formerly Mobility Electronics)
  development of the Series 60 version. 
