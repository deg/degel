// Clock VARs Start
var timeArray = [];
var currTop = timeLeft = currWidth = 0;
var h, m, s, commNo;
// Clock VARs End
// Browser params - Start
isNav = isIE = isIE55 = false;
browser = navigator.appName;
browserVer = navigator.appVersion;
if (browser == "Netscape") isNav = true;
else if (browser == "Microsoft Internet Explorer") isIE = true;
if (isIE){
   if (browserVer.indexOf("MSIE 5.5") != -1) isIE55 = true;
   document.write("<body>");currWidth = getWidth();document.write("</body>");
}
else currWidth = getWidth();
// Browser params - End
function titleView(title)
{
document.title = title;
//alert(document.title);
}

function getWidth(){
   if (isIE) return document.body.clientWidth;
	else return window.innerWidth;
}
if (document.layers){
	window.captureEvents(Event.RESIZE);
	window.onresize = handeleResize;
}
function handeleResize(){
   location.reload(); return false;
}
function pageInit(pageNum, commNum){
   commNo = commNum;
   if (pageNum == 1){
      currTop = 167;
      timeLeft = currWidth/2 + 135;
      if (document.layers){
         tickersLength = msgTexts.length;
         navInsertTicker(tickerCounter);
      }
   }
   else if (pageNum == 2){
      currTop = 111;
      timeLeft = currWidth/2 + 148;
   }
   else{
      currTop = 111;
      timeLeft = currWidth/2 + 147;
   }
   if (document.layers){
      if (document.layers.isTime) digiTime();
   }
   else{
      if (document.all.isTime) digiTime();
   }
}
function PopUpWin(mypage, myname, w, h, scroll){
   var winl = (screen.width)* 27/100;
 	var wint =(screen.height) * 18/100;
 	winprops = 'height='+h+',width='+w+',top='+wint+',left='+winl+',scrollbars='+scroll+',resizable';
 	win = window.open(mypage, myname, winprops);
 	if (parseInt(navigator.appVersion) >= 4) win.window.focus();
}
function chkSearch(word){
   if (word == "")return false;
   else return true;
}
// Clock functions Start 
//Clock Function
function digiTime(){
   if (!document.layers && !document.all)	return
   h = timeArray[0]; m = timeArray[1]; s = timeArray[2];
   if (s < 59) s = parseInt(s) + 1;
   else{
      s = 0;
      if (m < 59) m = parseInt(m) + 1;
      else{
         m = 0;
         if (h < 24) h = parseInt(h) + 1;
         else h = 1;
      }
   }
   timeArray[0] = h;
   timeArray[1] = m;
   timeArray[2] = s;
	var strH = strM = strS = "";
   if (h < 10) strH = "0" + h; else strH = h;
   if (m < 10) strM = "0" + m; else strM = m;
   if (s < 10) strS = "0" + s; else strS = s;
   if (strH.length == 3) strH = strH.substring(1, strH.length);
   if (strM.length == 3) strM = strM.substring(1, strM.length);
   if (strS.length == 3) strS = strS.substring(1, strS.length);
	digclock = '<span class="t11AquaBlue">' +  strH + ":" + strM + '</span>';//":" + strS + 
	if (document.layers){
      document.layers.isTime.top = parseInt(currTop);
      document.layers.isTime.left = parseInt(timeLeft);
      document.layers.isTime.document.open();
      document.layers.isTime.document.write(digclock);
		document.layers.isTime.document.close();
      document.layers.isTime.visibility = "show";
   }
   else if (document.all)
		isTime.innerHTML = digclock;
   setTimeout("digiTime()",1000)
}
//Insert server's time into array
function startTime(time){
   timeArray[0] = time.substring(0, time.indexOf(":"));
   timeArray[1] = time.substring(time.indexOf(":")+1, time.lastIndexOf(":"));
   timeArray[2] = time.substring(time.lastIndexOf(":")+1, time.length);
}
// Clock functions End
function PopUp(mypage, myname, w, h, scroll,t,l){
   var winL, winT;
   var a = arguments;
   if (a.length > 5){
      if (!document.layers){
         this.t = event.screenY + 30;
         this.l = event.screenX - w - 10;
      }
      if (a.length == 6){
         winT = t;
         winL = (screen.width) * 235/1000;
      }
      else{
         winT = t;
         winL = l;
      }
   }
   else{
      winL = (screen.width) * 235/1000;
      winT = (screen.height) * 40/100;
   }
   winprops = 'height='+h+',width='+w+',top='+winT+',left='+winL+',scrollbars='+scroll+',resizable';
   win = window.open(mypage, myname, winprops);
   if (parseInt(navigator.appVersion) >= 4)
      win.window.focus();
}
function pageArch(pID){
   if (pID == 45 ||pID == 47){
      if (document.all)
         document.all.wait.style.visibility="hidden";
   }
 }