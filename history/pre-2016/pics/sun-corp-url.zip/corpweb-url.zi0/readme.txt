Sun Microsystems, Inc. 
How to Use the Corporate Webtop Logo


Download Contents
This download folder contains Sun corporate webtop logo files.
Usage of the logos in this folder indicates that you have
reviewed the logo usage guidelines.

Summary of Logo Guidelines
� Do not separate or re-create any part of the logo.
� Keep all parts of the logo in proportion.  As the logo becomes larger, the trademark symbol becomes proportionally smaller.
� Leave 0.5 inches (12.5 mm) of clear space around the logo.
� The minimum logo size is 1.25" (or 32 mm). 
� There are two variations of the logo, small and large. The minimum logo size is 1.25 inches (or 32 mm) wide. If you are to reproduce the logo above 2.0875 inches (53 mm), please use the large version of the logo.
� Reproduce the logo only in Sun Blue, black, or white.
� Add hyperlinks to logos used on the Web.

For additional instructions on how to use Sun's corporate
logo, please visit the Usage Guidelines section.







Copyright 1994-2002 Sun Microsystems, Inc., 901 San Antonio Road, Palo 
Alto, CA 94303 USA. All rights reserved.
